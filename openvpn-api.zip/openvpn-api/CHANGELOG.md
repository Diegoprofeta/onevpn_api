# OpenVPN-Admin Version History

## 0.3.2
- Fix with MySQL NO_ZERO_DATE mode

## 0.3.1
- Fix path issues

## 0.3.0
- Add title to webpage
- Improve design and user experience
- Add redirections (after install...)
- Upgrade to EasyRSA 3.x
- Files are in a subdirectory in the Zip configuration
