* **PHP version:**
* **MySQL version:**
* **Webserver (Nginx, Apache...):**
* **What is the expected behaviour?**
* **What do you see instead?**
* **PHP logs on pastebin:**
