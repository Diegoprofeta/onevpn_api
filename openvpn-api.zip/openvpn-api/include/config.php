<?php
	$host = 'localhost';
	$port = '3306';
	$db   = 'openvpn-admin';
	$user = '';
	$pass = '';
?>
