#!/bin/bash

# MySQL credentials
HOST='localhost'
PORT='3306'
USER=''
PASS=''
DB='openvpn-admin'
