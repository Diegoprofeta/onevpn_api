# Screenshots

## Login

![Status page](images/preview_login.png?raw=true)

## Status

![Status page](images/preview_status.png?raw=true)

## Certificates

![Status page](images/preview_certificates.png?raw=true)

## OpenVPN config

![Status page](images/preview_openvpn_config.png?raw=true)
